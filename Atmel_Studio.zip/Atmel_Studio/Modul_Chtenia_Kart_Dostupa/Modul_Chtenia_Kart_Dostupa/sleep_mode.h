/*
 * sleep_mode.h
 *
 * Created: 30.07.2023 17:35:25
 *  Author: stepan
 */ 


#ifndef SLEEP_MODE_H_
#define SLEEP_MODE_H_

#include <avr/sleep.h>

void sleep();



#endif /* SLEEP_MODE_H_ */